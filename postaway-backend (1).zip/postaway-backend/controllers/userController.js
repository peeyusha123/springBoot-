import User from '../models/User.js';
import generateToken from '../utils/generateToken.js';

export const registerUser = (req, res, next) => {
  const { name, email, password } = req.body;
  try {
    const newUser = User.addUser(name, email, password);
    res.status(201).json({ ...newUser, token: generateToken(newUser.id) });
  } catch (error) {
    next(error);
  }
};

export const loginUser = (req, res, next) => {
  const { email, password } = req.body;
  try {
    const user = User.login(email, password);
    res.json({ ...user, token: generateToken(user.id) });
  } catch (error) {
    next(error);
  }
};
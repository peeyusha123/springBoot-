const users = [];

let userIdCounter = 1;

const User = {
  addUser: (name, email, password) => {
    if (users.find(u => u.email === email)) {
      throw new Error('User already exists');
    }
    const user = { id: userIdCounter++, name, email, password };
    users.push(user);
    return user;
  },
  login: (email, password) => {
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) throw new Error('Invalid credentials');
    return user;
  },
  getAll: () => users
};

export default User;
export const logger = (req, res, next) => {
  if (!req.url.startsWith('/api/users')) {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    console.log('Body:', req.body);
  }
  next();
};
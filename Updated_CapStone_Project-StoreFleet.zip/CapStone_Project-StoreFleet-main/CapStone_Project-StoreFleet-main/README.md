
# 📦 StoreFleet – Backend API

## 📝 Overview

StoreFleet is a backend system developed using **Node.js**, **Express**, **MongoDB**, and **Nodemailer**, designed for managing users, products, and orders. It ensures secure interactions through authentication, password recovery features, and robust admin control. The API enables a smooth shopping experience, from account creation to placing and tracking orders.

## 🚀 Key Features

- **Authentication & Authorization**  
  Uses bcrypt to hash passwords and JWT for secure login and session management.

- **User Management**  
  Create, update, and manage users with role-based access control for regular users and administrators.

- **Product Operations**  
  Add, update, view, and remove products. Includes features like filtering and product reviews.

- **Order Handling**  
  Place and manage orders with detailed tracking of shipping, payment, and pricing breakdown.

- **Password Reset System**  
  Email-based password reset process with token verification for enhanced account security.

## 🔧 Tech Stack

- Node.js  
- Express.js  
- MongoDB  
- Mongoose  
- Nodemailer  
- JWT  
- Bcrypt

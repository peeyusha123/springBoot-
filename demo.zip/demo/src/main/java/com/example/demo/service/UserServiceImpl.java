package com.example.demo.service;

import com.example.demo.dao.UserDao;
import com.example.demo.dao.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public void addUser(User user) {
        userDao.addUser(user);
    }

    @Override
    public void resetUsername(Long userId, String newUsername) {
        userDao.resetUsername(userId, newUsername);
    }

    @Override
    public String validateLogin(String username, String password) {
        User user = userDao.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            // Generate and return a session token
            String sessionToken = generateSessionToken();
            return "Login successful. Session Token: " + sessionToken;
        } else {
            return "Invalid username or password";
        }
    }

    private String generateSessionToken() {
        // Implement session token generation logic
        // You can use libraries like UUID.randomUUID().toString()
        return "GeneratedSessionToken";
    }
}

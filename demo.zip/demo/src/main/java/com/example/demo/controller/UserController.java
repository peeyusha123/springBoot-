package com.example.demo.controller;

import com.example.demo.dao.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/get-example")
    public ResponseEntity<String> getExample() {
        return ResponseEntity.ok("This is a GET example");
    }

    @PostMapping("/add")
    public ResponseEntity<String> addUser(@RequestBody User user) {
        userService.addUser(user);
        return ResponseEntity.ok("User added successfully");
    }

    @PostMapping("/reset-username")
    public ResponseEntity<String> resetUsername(@RequestParam Long userId, @RequestParam String newUsername) {
        userService.resetUsername(userId, newUsername);
        return ResponseEntity.ok("Username reset successfully");
    }

    @PostMapping("/validate-login")
    public ResponseEntity<String> validateLogin(@RequestParam String username, @RequestParam String password) {
        String result = userService.validateLogin(username, password);
        return ResponseEntity.ok(result);
    }
}

package com.example.demo.service;

import com.example.demo.dao.User;

public interface UserService {
    void addUser(User user);
    void resetUsername(Long userId, String newUsername);
    String validateLogin(String username, String password);
}
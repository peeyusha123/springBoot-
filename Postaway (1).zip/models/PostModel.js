import { posts } from '../data/posts.js';
import { v4 as uuidv4 } from 'uuid';

export const createPost = ({ userId, caption, imageUrl }) => {
    const post = { id: uuidv4(), userId, caption, imageUrl, createdAt: new Date(), archived: false, draft: false };
    posts.push(post);
    return post;
};

export const getAllPosts = () => posts;

export const getPostById = (id) => posts.find(p => p.id === id);

export const getPostsByUser = (userId) => posts.filter(p => p.userId === userId);

export const updatePost = (id, data) => {
    const post = getPostById(id);
    if (post) Object.assign(post, data);
    return post;
};

export const deletePost = (id) => {
    const index = posts.findIndex(p => p.id === id);
    if (index !== -1) posts.splice(index, 1);
};
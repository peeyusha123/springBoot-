import { users } from '../data/users.js';
import { v4 as uuidv4 } from 'uuid';

export const addUser = ({ name, email, password }) => {
    const user = { id: uuidv4(), name, email, password };
    users.push(user);
    return user;
};

export const getUserByEmail = (email) => users.find(user => user.email === email);

export const getAllUsers = () => users;
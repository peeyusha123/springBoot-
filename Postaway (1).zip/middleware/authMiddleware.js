import jwt from 'jsonwebtoken';
import { AppError } from './errorMiddleware.js';
import { users } from '../data/users.js';

export const protect = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        throw new AppError('No token provided', 401);
    }

    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, 'secret');
        const user = users.find(u => u.id === decoded.id);
        if (!user) throw new AppError('User not found', 404);
        req.user = user;
        next();
    } catch (err) {
        throw new AppError('Invalid token', 401);
    }
};
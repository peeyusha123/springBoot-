export const logger = (req, res, next) => {
    if (!req.originalUrl.startsWith('/api/users')) {
        console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
        console.log('Body:', req.body);
    }
    next();
};
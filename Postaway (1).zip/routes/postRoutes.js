import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import { upload } from '../middleware/uploadMiddleware.js';
import {
    create,
    getAll,
    getById,
    getUserPosts,
    update,
    remove
} from '../controllers/postController.js';

const router = express.Router();

router.get('/all', getAll);
router.get('/:id', getById);
router.use(protect);
router.get('/', getUserPosts);
router.post('/', upload.single('image'), create);
router.put('/:id', upload.single('image'), update);
router.delete('/:id', remove);

export default router;
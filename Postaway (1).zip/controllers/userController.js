import { addUser, getUserByEmail } from '../models/UserModel.js';
import { generateToken } from '../utils/generateToken.js';
import { AppError } from '../middleware/errorMiddleware.js';

export const registerUser = (req, res) => {
    const { name, email, password } = req.body;
    if (getUserByEmail(email)) {
        throw new AppError('User already exists', 400);
    }
    const user = addUser({ name, email, password });
    res.status(201).json({ ...user, token: generateToken(user.id) });
};

export const loginUser = (req, res) => {
    const { email, password } = req.body;
    const user = getUserByEmail(email);
    if (!user || user.password !== password) {
        throw new AppError('Invalid credentials', 401);
    }
    res.json({ ...user, token: generateToken(user.id) });
};
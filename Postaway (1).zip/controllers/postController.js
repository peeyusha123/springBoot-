import {
    createPost,
    getAllPosts,
    getPostById,
    getPostsByUser,
    updatePost,
    deletePost
} from '../models/PostModel.js';
import { AppError } from '../middleware/errorMiddleware.js';

export const create = (req, res) => {
    const { caption } = req.body;
    const imageUrl = req.file ? req.file.path : '';
    const post = createPost({ userId: req.user.id, caption, imageUrl });
    res.status(201).json(post);
};

export const getAll = (req, res) => res.json(getAllPosts());

export const getById = (req, res) => {
    const post = getPostById(req.params.id);
    if (!post) throw new AppError('Post not found', 404);
    res.json(post);
};

export const getUserPosts = (req, res) => res.json(getPostsByUser(req.user.id));

export const update = (req, res) => {
    const updated = updatePost(req.params.id, req.body);
    if (!updated) throw new AppError('Post not found', 404);
    res.json(updated);
};

export const remove = (req, res) => {
    deletePost(req.params.id);
    res.status(204).end();
};